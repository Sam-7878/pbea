논문 전체(서론~결론)와 참고문헌 파일을 모두 읽었습니다. SCI(E)급 저널 투고를 전제로 리뷰해 드립니다.

---

## 종합 평가

주장 범위를 신중하게 한정(bounded claims)하고, 위협모델→보안목표→시나리오→지표가 일관되게 연결된 점은 보안 분야 논문으로서 성숙한 구성입니다. 다만 현재 상태로는 **(1) 본문에 없는 Implementation 절, (2) 대상 저널(ICT Express)과 분량의 불일치, (3) 평가의 자기참조성(self-referential ablation), (4) 최신 학술문헌 부족**이 게재 결정에 직접 영향을 줄 수 있는 핵심 리스크입니다.

---

## 1. 반드시 수정해야 할 사항 (Critical)

### 1-1. Implementation 절이 없음
서론 마지막 로드맵에 "Section~\ref{sec:implementation} describes the Rust and OpenBSD reference implementation"이 있고 RQ5·평가 절에서도 구현을 전제하지만, 실제 본문에는 `\section{Implementation}`이 존재하지 않습니다. Architecture(Sec. 4)에서 곧바로 Comparative Security Evaluation으로 넘어갑니다. `\ref{sec:implementation}`은 컴파일 시 "??"로 출력됩니다.
- **조치**: 구현 절을 추가(crate 구성, 정책 스키마/JCS 정규화(RFC 8785 인용을 이미 갖고 있음), unveil/pledge 매핑 코드 구조, 검증 하네스)하거나, 로드맵 문장과 참조를 삭제하고 구현 내용을 Architecture/Evaluation에 흡수하십시오. 재현성 관점에서 **구현 절 추가 + 코드/데이터 공개(artifact availability statement)**를 강력히 권합니다. 현재 `raw/*.jsonl`, commit `1bcfa8b`를 언급하면서 접근 방법이 없어 리뷰어가 검증 불가능하다고 지적할 수 있습니다.

### 1-2. 저널 적합성과 분량
`\journal{ICT Express}`로 되어 있는데, ICT Express는 **8페이지 내외의 short-paper 저널**입니다. 파일명(19p)대로 19페이지 분량이면 데스크 리젝 사유입니다.
- 이 분량과 깊이라면 **Computers & Security, Journal of Information Security and Applications (JISA), Computer Networks, IEEE TDSC, ACM TOPS** 등 full-length 보안 저널이 적합합니다.
- ICT Express를 고수한다면 문제모델·아키텍처·한계 절을 절반 이하로 압축해야 하며, 현재 논문의 강점(정밀한 claim bounding)이 훼손됩니다. 저널 재선정을 권합니다.
- 초록도 현재 4문단으로 깁니다. Elsevier 보안 저널 기준 150–250 단어로 압축 필요.

### 1-3. 평가의 자기참조성 — 리뷰어 최대 공격 지점
B0/B1/P가 같은 코드베이스의 ablation이라는 점은 내적 타당성에는 좋지만, 결과 대부분이 **"메커니즘을 껐으니 공격이 성공하고, 켰으니 막힌다"는 구성상 결정론적 결과**입니다. 30회 반복과 Wilson CI는 결정론적 픽스처에서 통계적 의미가 거의 없습니다(저자도 인정하고 있으나, 인정만으로 방어가 안 됩니다). 보강 방안:
1. **Sandbox-only(B2) ablation 추가** — 본문에서 "포함하지 않았다"고 스스로 인정한 부분입니다. B2가 S2–S4는 막지만 S1/S6–S8을 못 막는다는 결과가 있어야 "두 계층이 서로 대체 불가"라는 핵심 주장(ablation의 대칭성)이 완성됩니다. 이건 큰 비용 없이 추가 가능하며 논문 설득력을 크게 올립니다.
2. **정책 우회 시도(adaptive adversary)** 시나리오 최소 1–2개: 예컨대 허용된 파일 경로를 통한 심볼릭 링크/TOCTOU, 허용된 endpoint를 통한 exfiltration 시도가 실제로 정책 범위 내에서 성공함을 보여주면 오히려 claim boundary의 정직성이 실증됩니다.
3. **실제 유사 워크로드**(예: 간단한 REST 트랜잭션 서비스)에서 S0-only steady-state latency를 측정해 RQ5를 실측으로 대체. 현재 "benign-only S0 latency table should be generated ... before the final manuscript artifact is frozen"이라는 문장은 **내부 TODO 메모가 본문에 남은 것**으로, 투고 전 반드시 해당 표를 실제로 생성해 넣고 이 문장(평가 절과 한계 절 두 곳)을 제거해야 합니다.

### 1-4. 관련연구의 학술 문헌 부족
참고문헌 22건 중 다수가 NIST 보고서, OS 매뉴얼, OWASP 웹문서이고, 동료심사 학술논문은 고전(1975–2010)에 치우쳐 있습니다. 2020년 이후 학술 문헌이 사실상 없습니다. SCI 저널 리뷰어는 다음 영역의 최신 연구와의 비교를 요구할 것입니다:
- ZTA 학술 서베이 및 continuous authorization 최신 연구 (예: Buck et al. 2021, Syed et al. 2022 ZTA survey)
- eBPF/Landlock 기반 런타임 정책 집행, container runtime security (Falco, Tetragon 계열 연구)
- Information-flow control / decentralized IFC (예: HiStar, Flume) — "정책과 실행 효과의 결합"이라는 관점에서 개념적으로 가장 가까운 선행 연구군인데 현재 언급이 없습니다
- Attribute-based / intent-based policy binding, in-toto·attestation 계열
- Transactional / speculative execution isolation (candidate-state isolation과 유사한 DB·STM 개념의 보안 응용)

각 5–10건을 추가하고 Positioning 표에 1–2행을 보강하십시오.

---

## 2. 내용 보강 제안 (Major)

1. **"Process Trust" 개념의 정식화 강화**: Eq.(process_trust)가 사실상 정의인데, 본문 제목("From Access Trust to Process Trust")의 핵심 개념치고는 Discussion에 늦게 등장합니다. Problem Model 절에서 정의하고 평가 목표와 명시적으로 연결하는 편이 좋습니다.
2. **S8/B0 분류의 방어**: B0는 digest를 아예 검사하지 않으므로 "30/30 성공"은 정의상 성공입니다. 본문에 "under the evaluation classification"이라는 단서가 있지만, 리뷰어가 metric inflation으로 볼 수 있으니 MESR을 "capability 계열(S2–S4)"과 "binding 계열(S1, S8 등)"로 분리 보고하는 것을 고려하십시오. 180/180→90/180→0/180이라는 헤드라인 숫자가 지금은 분모 구성에 민감합니다.
3. **정책 작성 비용**: Deployment 절에서 정성적으로만 다룹니다. 평가에 사용한 실제 효과 정책(YAML/JSON)의 크기·항목 수·작성 공수를 부록으로 제시하면 실용성 주장이 구체화됩니다.
4. **Linux 백엔드 논의 구체화**: seccomp/Landlock 매핑 가능성을 나열만 하는데, `P_R` 각 요소가 Landlock·seccomp·cgroup 중 무엇에 대응되는지 표 하나로 제시하면 일반성 주장이 강해집니다.
5. **Quarantine의 in-memory 한계**: 여러 곳에서 반복 인정하고 있는데, 반복 서술을 줄이고 Limitations 한 곳으로 모으십시오. 현재 논문 전반적으로 동일한 caveat(“not universal prevention…”)이 초록·서론·평가·토론·한계·결론에 6회 이상 반복됩니다. 정직성은 미덕이지만 과도한 반복은 분량을 늘리고 기여를 스스로 희석합니다. 초록 1회 + Limitations 1회로 충분합니다.

---

## 3. 편집·형식 사항 (Minor)

- **`tablenotes`/`\tnote{a}` 사용 오류**: Table `tab:mode_configuration`에서 `threeparttable` 환경 없이 `\begin{tablenotes}`와 `\tnote`를 사용 — 컴파일 오류 또는 각주 미표시가 발생합니다. `\begin{threeparttable}…\end{threeparttable}`로 감싸십시오.
- **참고문헌 파일**: `references.tex`는 실제로 BibTeX 내용이므로 `references.bib`로 이름을 바꿔야 `\bibliography{references}`가 동작합니다.
- **서지 스타일**: elsarticle + `IEEEtran` 조합은 Elsevier 저널 규정과 안 맞습니다. `elsarticle-num` 사용 권장.
- 패키지 중복 로드: `tikz`, `url` 각 2회.
- 소스 내 한국어 주석("필수 패키지 로드", "감사의 글" 등)은 투고 전 제거.
- "The generated artifact originally labels this quantity 'CER'…" — 내부 개발 이력 서술로, 논문 본문에 부적절합니다. 삭제하고 CCR만 사용.
- "Historical source packages retain the `poa-*` crate prefix" — 익명 심사 시 프로젝트 추적 단서가 될 수 있고 독자에게 불필요한 정보입니다. 코드 공개 시 README로 옮기는 것을 권장.
- RQ 목록이 서론과 평가 절에 거의 동일하게 2회 등장 — 한 곳으로 통합.
- `100% = 180/180` 같은 자명한 분수를 display equation으로 번호 붙인 부분(ablation analysis)은 본문 인라인으로.
- Acknowledgment의 IITP 과제번호가 "IITP-2026-…"로 되어 있는데 실제 과제 표기 확인 필요.
- 이중 게재 방지 관점에서, 익명화가 필요한 저널(더블블라인드)로 갈 경우 소속·사사 처리 방식 확인.

---

## 우선순위 요약

| 순위 | 항목 | 성격 |
|---|---|---|
| 1 | Implementation 절 추가(또는 참조 정리) + 아티팩트 공개 | 필수 |
| 2 | 저널 재선정(분량 vs ICT Express 8p 제한) | 필수 |
| 3 | 본문 내 TODO 문장 제거 및 S0 latency 표 실제 생성 | 필수 |
| 4 | Sandbox-only(B2) ablation 추가 | 강력 권장 |
| 5 | 2020년 이후 학술문헌 10건+ 보강(특히 IFC, eBPF/Landlock 계열) | 강력 권장 |
| 6 | threeparttable 오류, .bib 파일명, 서지 스타일 등 형식 수정 | 필수(경미) |
| 7 | caveat 반복 축소, MESR 분해 보고 | 권장 |

원하시면 (1) Implementation 절 초안 작성, (2) 특정 저널(예: Computers & Security 또는 JISA) 양식에 맞춘 구조 개편안, (3) 추가해야 할 최신 참고문헌의 구체 목록 검색 중 어느 것이든 이어서 도와드리겠습니다.