# PBEA 논문 보강을 위한 추가 개발·재실험 작업지시서

## 1. 작업 목적

현재 PBEA 논문의 1차 comparative evaluation은 다음 세 configuration을 사용한다.

- B0: Access-only
- B1: Transition-only
- P: Full-PBEA

기존 실험은 application transition integrity를 추가한 B1과 runtime confinement까지 추가한 P를 비교함으로써, transition control만으로는 filesystem, child-process, endpoint capability effect를 제어할 수 없음을 보여준다.

그러나 현재 설계에는 반대 방향의 ablation, 즉 **runtime confinement만 활성화하고 transition integrity를 비활성화한 configuration**이 존재하지 않는다.

이번 작업의 제1목표는 **B2: Runtime-only configuration을 추가하여 transition integrity와 runtime confinement가 서로 대체할 수 없는 독립적 보안 경계임을 실험적으로 검증하는 것**이다.

제2목표는 기존 mixed-scenario timing이 아닌 **정상적인 benign S0 execution의 steady-state latency를 별도로 측정하여 PBEA 정상 실행 비용을 정량화하는 것**이다.

제3목표는 PBEA가 정책 밖의 effect를 제한하는 architecture이지 모든 악의적 의도를 탐지하는 시스템이 아님을 보이기 위한 **claim-boundary / adaptive-adversary experiment**를 추가하는 것이다.

이번 작업의 최종 산출물은 논문 문장이 아니라 다음이어야 한다.

1. 수정된 Rust implementation
2. 새 comparative experiment
3. raw evidence
4. validator 결과
5. benchmark raw data
6. 자동 생성된 CSV/LaTeX tables
7. SHA-256 manifest
8. 재현 가능한 실행 명령 및 실험 보고서

논문 본문 수정은 이 작업의 실험 결과가 확정된 후 별도 단계에서 수행한다.

---

# 2. 가장 중요한 실험 원칙

## 2.1 기존 결과와 새로운 결과를 혼합하지 말 것

현재 논문 결과는 frozen source revision `1bcfa8b`를 기준으로 생성되어 있다.

B2 및 benchmark 기능을 추가하면 source revision이 변경되므로 기존 B0/B1/P raw 결과를 새로운 B2 결과와 결합해서는 안 된다.

새로운 implementation commit을 freeze한 후 반드시 다음 전체 matrix를 다시 실행한다.

\[
4\ modes \times 9\ scenarios \times 30\ iterations
=1080\ records
\]

즉 최종 comparative corpus는 최소:

- B0 × S0–S8 × 30
- B1 × S0–S8 × 30
- B2 × S0–S8 × 30
- P × S0–S8 × 30

의 **1080 records**이어야 한다.

기존 810-record corpus와 새 1080-record corpus의 결과를 섞어 계산해서는 안 된다.

---

# 3. Task A — B2 Runtime-only configuration 구현

## 3.1 목적

현재 B0→B1→P 실험은 다음 명제를 검증한다.

> Transition integrity alone does not substitute for runtime-capability confinement.

이번 B2를 통해 반대 명제도 검증한다.

> Runtime-capability confinement alone does not substitute for application transition integrity and policy binding.

두 결과가 함께 존재해야 다음 PBEA 핵심 주장을 실험적으로 뒷받침할 수 있다.

> Application transition integrity and runtime-capability confinement are complementary and non-substitutable security boundaries.

---

## 3.2 VerifierMode 확장

현재 closed enumeration에 다음 mode를 추가한다.

```rust
enum VerifierMode {
    AccessOnly,
    TransitionOnly,
    RuntimeOnly,
    FullPbea,
}
```

명칭은 source code에서는 `RuntimeOnly`를 우선 사용한다.

논문에서는 이후:

> B2 — Runtime-only

로 표현할 예정이다.

---

## 3.3 B2의 보안 기능 정의

B2는 가능한 한 다음 configuration을 가져야 한다.

| Mechanism | B0 | B1 | B2 Runtime-only | P |
|---|---:|---:|---:|---:|
| Authentication/access precondition | Yes | Yes | Yes | Yes |
| Shared parser/operation path | Yes | Yes | Yes | Yes |
| AACO transition enforcement | No | Yes | No | Yes |
| Candidate-state isolation | No | Yes | No | Yes |
| Invariant reconciliation | No | Yes | No | Yes |
| PBEA outcome enforcement | No | Yes | No | Yes |
| Request/effective-policy digest binding | No | Yes | No | Yes |
| Endpoint restriction | No | No | Yes | Yes |
| Required runtime-resource validation | No | No/Partial | Yes | Yes |
| OpenBSD unveil | No | No | Yes | Yes |
| OpenBSD pledge | No | No | Yes | Yes |
| Fail-closed runtime-policy startup | No | Partial | Yes | Yes |

주의:

B2가 runtime policy를 읽고 `unveil`/`pledge`를 설정하는 것과 **request가 제시한 policy digest를 transition/evidence semantics와 binding하는 것**은 다른 기능이다.

B2에서는 runtime confinement 설정을 위해 effective runtime policy를 사용할 수 있지만, PBEA transition-layer policy-digest binding은 활성화하지 않는다.

이 구분을 코드에서 명시적으로 유지한다.

---

# 4. Task B — B2 scenario semantics 정의 및 실험

기존 S0–S8 probe를 가능한 한 수정하지 않고 동일하게 재사용한다.

B2의 핵심 hypothesis는 다음과 같다.

## S0 — Benign operation

예상:

- 정상 operation 성공
- runtime policy가 허용한 filesystem/process/network capability만 사용
- benign effect preserved

B2가 모든 요청을 차단하여 보안을 달성해서는 안 된다.

---

## S1 — Invariant violation

B2에는 candidate-state invariant reconciliation이 없으므로 runtime sandbox만으로는 domain semantic invariant를 판단할 수 없어야 한다.

핵심 검증 질문:

> Does runtime confinement prevent an otherwise permitted process from committing an invalid application state?

예상 hypothesis:

**No.**

즉 B2에서 S1의 prohibited state effect가 관측될 가능성이 있으며 이것이 B2의 설계 목적과 일치한다.

결과를 강제로 이 hypothesis에 맞추지 말고 실제 observable state effect를 기록한다.

---

## S2 — Policy-external file read

B2의 `unveil` boundary가 활성화되어야 한다.

예상:

- controlled file disclosure 실패
- native filesystem denial evidence 확보
- observable effect success = false

---

## S3 — Undeclared child execution

B2의 `pledge` boundary가 활성화되어야 한다.

예상:

- controlled helper의 실제 successful execution 방지
- marker 생성 여부 확인
- exit/signal/native evidence 기록

---

## S4 — Disallowed endpoint

B2의 application endpoint restriction을 활성화한다.

예상:

- disallowed loopback endpoint로 connection/data delivery 실패
- sink에서 실제 delivery 여부를 확인할 것

단순 application return code만으로 containment를 판정하지 않는다.

---

## S5 — Invalid startup / missing runtime resource

B2는 runtime enforcement configuration을 실제로 사용하는 mode이므로 Full-PBEA와 마찬가지로 필요한 runtime policy/resource를 준비하지 못한 경우 protected business loop에 진입해서는 안 된다.

따라서 B2에서도 다음 두 subcase를 평가한다.

- malformed runtime policy
- missing required runtime resource

예상:

> fail closed before protected execution

단, B2와 P의 차이는 transition semantics 및 policy binding에 있으며 runtime startup safety는 두 mode 모두 적용할 수 있다.

---

## S6 — Repeated policy violation / quarantine

B2에는 PBEA transition-layer trust/quarantine semantics를 적용하지 않는다.

핵심 질문:

> Does runtime sandboxing alone produce PBEA's differentiated quarantine/trust-state response?

예상:

**No.**

단, OS-level denial 자체는 정상적으로 발생할 수 있다.

즉 다음을 구분하여 기록한다.

- capability denial
- PBEA Quarantine outcome
- trust-state update

이 세 가지를 동일한 사건으로 취급하지 말 것.

---

## S7 — Failure after candidate creation

B2는 candidate-state isolation을 제공하지 않는 configuration이다.

기존 S7 probe를 최대한 그대로 사용하되, B2에서 candidate-state mechanism이 비활성화되었을 때 동일 fault point를 어떻게 재현할 수 있는지 먼저 검토한다.

두 가지 중 실제 implementation과 일치하는 방법을 선택한다.

1. Access-only direct mutation path에서 equivalent internal failure를 inject하여 부분 state propagation 여부를 관측하거나,
2. B2에서는 S7을 transition-layer non-applicable scenario로 명시한다.

임의로 성공/실패 결과를 만들어서는 안 된다.

가능하면 1번 방식을 우선하여 runtime-only가 transactional candidate isolation을 제공하지 않는다는 점을 observable state로 검증한다.

---

## S8 — Wrong effective-policy digest

B2에서는 PBEA policy-digest binding을 비활성화한다.

따라서 wrong/stale digest가 runtime confinement 자체에 의해 거부되는 것처럼 구현해서는 안 된다.

핵심 질문:

> Does a runtime sandbox by itself bind an admitted request to the exact effective PBEA policy identity?

예상 hypothesis:

**No.**

이를 통해 B1과 B2의 비대칭성이 명확해져야 한다.

---

# 5. Task C — 전체 4-mode comparative experiment 재실행

B2 구현 완료 후 새로운 source revision을 freeze한다.

예:

```text
PBEA_EVAL_COMMIT=<new frozen commit>
```

이 commit을 모든 raw evidence에 기록한다.

다음 matrix를 OpenBSD 7.9에서 실행한다.

```text
B0 Access-only       : S0-S8 × 30
B1 Transition-only   : S0-S8 × 30
B2 Runtime-only      : S0-S8 × 30
P  Full-PBEA         : S0-S8 × 30
```

목표 corpus:

```text
4 × 9 × 30 = 1080 records
```

각 record에는 최소 다음 필드를 포함한다.

- source_commit
- platform / OS version
- mode
- scenario
- iteration
- authentication status
- access-authorization status
- expected observation/classification
- observed outcome
- attempted state effect
- successful state effect
- attempted runtime effect
- successful runtime effect
- state hash before
- state hash after
- effective policy digest, where applicable
- native errno
- process exit code
- process signal
- helper marker status
- endpoint sink observation
- business-loop entry state
- duration
- evidence timestamp / run identifier

---

# 6. Task D — raw evidence file 구조 변경

새 corpus는 최소 다음 네 파일로 분리한다.

```text
raw/access-only.jsonl
raw/transition-only.jsonl
raw/runtime-only.jsonl
raw/full-pbea.jsonl
```

기존 3-mode artifact와 혼동하지 않도록 새 experiment root를 사용할 것을 권장한다.

예:

```text
evaluation/runs/pbea_4mode_v2/
```

하위 예:

```text
raw/
generated/
benchmark/
boundary/
manifest/
logs/
```

---

# 7. Task E — Validator를 4-mode 구조로 확장

현재 validator가 3-mode closed matrix를 전제로 한다면 이를 4-mode로 수정한다.

Validator는 최소 다음 오류를 탐지해야 한다.

1. mode 누락
2. scenario 누락
3. iteration 누락/중복
4. source commit 불일치
5. OS/platform 불일치
6. 동일 mode-scenario 조합에서 30 records 미달
7. unexpected weaker-mode fallback
8. state hash inconsistency
9. impossible runtime-effect classification
10. evidence schema mismatch

전체 corpus validation 조건:

```text
validated_records == 1080
```

이어야 한다.

Validator가 성공하기 전에는 metrics 또는 paper table을 생성해서는 안 된다.

---

# 8. Task F — Metric reporting을 effect family별로 분리

기존 aggregate MESR은 유지 가능하지만 **primary result로 사용하지 않는다.**

새 reporting pipeline에서는 적어도 다음 effect families를 별도 계산한다.

## F1. State integrity

대상:

- S1
- 필요한 경우 S7

보고 항목:

- attempted invalid state effects
- successful invalid state effects
- non-commit state preservation
- before/after hash consistency

---

## F2. Runtime capability containment

대상:

- S2
- S3
- S4

현재 CCR 개념을 유지할 수 있다.

보고:

```text
contained capability attempts /
attempted prohibited capability effects
```

S2, S3, S4를 개별적으로도 반드시 출력한다.

---

## F3. Policy binding

대상:

- S8

별도 metric을 추가한다.

예:

```text
Policy-Binding Violation Acceptance Rate
```

또는 의미가 명확한 동등한 명칭을 사용한다.

핵심은 wrong/stale digest가 accepted/executed 되었는지를 다른 capability effect와 분리해서 보여주는 것이다.

---

## F4. Fail-closed startup

대상:

- S5

기존 FCR 개념을 유지한다.

malformed-policy와 missing-resource subcase를 분리해서도 보고한다.

---

## F5. Outcome / quarantine semantics

대상:

- S6
- 필요시 S7

다음을 분리한다.

- runtime denial
- Reject
- Quarantine
- Abort
- trust-state update
- domain-state propagation

---

## F6. Benign preservation

대상:

- S0

기존 BRSR을 유지한다.

---

## F7. Aggregate MESR

전체 aggregate MESR은 계산하되 다음 조건을 따른다.

- secondary summary로만 출력
- family별 결과와 함께 생성
- heterogeneous effect를 하나의 security probability처럼 해석하지 않음

---

# 9. Task G — S0-only steady-state benchmark 구현

기존 mixed-scenario duration은 production request latency를 의미하지 않는다.

따라서 별도의 benign-only benchmark를 구현한다.

## G1. 목적

다음 질문에 답할 수 있어야 한다.

> What incremental steady-state execution cost is observed for a policy-conforming benign PBEA operation?

---

## G2. benchmark 대상 mode

가능하면 네 mode 모두 측정한다.

- B0
- B1
- B2
- P

최소한 논문 headline 비교에는:

- B0
- P

가 반드시 포함되어야 한다.

---

## G3. startup과 steady-state를 분리

PBEA의 policy parsing, resource preparation, `unveil`, `pledge` installation은 service startup cost와 request-path cost가 섞일 수 있다.

따라서 최소 두 measurement category를 분리한다.

### Startup benchmark

측정 가능한 경우:

- policy load
- schema validation
- policy resolution
- canonicalization / digest
- resource preparation
- runtime confinement setup
- protected loop ready

까지의 startup cost를 별도로 측정한다.

### Steady-state S0 benchmark

primary metric이다.

runtime policy와 sandbox가 이미 설치된 long-lived process 상태에서 동일한 benign S0 operation을 반복 실행한다.

**프로세스 생성 비용을 매 request latency에 포함시키지 말 것.**

---

## G4. 반복 수

Latency distribution을 얻기 위해 30회보다 더 많은 sample을 사용한다.

권장 기본값:

```text
warmup: 100 operations
measured: >= 1000 operations per mode
```

가능하면 여러 batch로 분리한다.

예:

```text
5 batches × 1000 operations
```

단, implementation 제약이 있다면 그 이유를 문서화하고 현실적인 최대 반복 수를 사용한다.

---

## G5. 측정 조건

모든 mode에서 다음을 동일하게 유지한다.

- 동일 source commit
- 동일 release build
- 동일 OpenBSD VM
- 동일 request
- 동일 actor
- 동일 asset
- 동일 operation
- 동일 valid policy
- 동일 input
- 동일 evidence setting
- 동일 log level
- 동일 machine load 조건

고해상도 monotonic clock을 사용한다.

---

## G6. benchmark 결과

각 mode별로 최소 다음 값을 자동 계산한다.

- N
- Min
- P50
- P95
- P99
- Max
- Mean
- Standard deviation

그리고 B0 대비 다음을 계산한다.

```text
P50 overhead
P95 overhead
P99 overhead
```

예:

```text
(P_P50 - B0_P50) / B0_P50 × 100
```

수치는 반드시 raw benchmark data에서 reporting script가 생성한다.

수동 계산된 논문용 숫자를 코드에 hard-code하지 말 것.

---

# 10. Task H — Claim-Boundary / Adaptive-Adversary experiment

기존 S0–S8 matrix와 별도로 수행한다.

이 실험의 목적은 PBEA가 “모든 malicious behavior를 막는다”는 것을 증명하는 것이 아니다.

오히려 다음 claim boundary를 검증한다.

> PBEA constrains effects outside the declared policy but does not infer malicious intent for effects that the policy explicitly permits.

---

## H1. Boundary Test 1 — Allowed endpoint misuse

controlled loopback endpoint를 effective policy에 명시적으로 허용한다.

그 endpoint로 marker/test payload를 전송한다.

Full-PBEA에서:

- endpoint가 allowlist에 존재하고
- 다른 policy condition을 위반하지 않는다면

delivery가 성공해야 한다.

이 결과는 security failure로 분류하지 않는다.

보고 의미:

> Full-PBEA does not claim to prevent exfiltration through a destination that the declared policy itself explicitly allows.

실제 sensitive data는 사용하지 않는다.

controlled marker payload만 사용한다.

---

## H2. Boundary Test 2 — Filesystem path / symlink adaptive probe

안전한 synthetic directory hierarchy 안에서 symlink 또는 equivalent path-resolution edge case를 구성한다.

목적:

> Can an allowed filesystem path be used to reach an object outside the intended filesystem boundary?

반드시 controlled test file만 사용한다.

OpenBSD `unveil`의 실제 semantics를 관찰하며 결과를 미리 hard-code하지 않는다.

가능한 결과:

- kernel enforcement가 우회를 막음
- 특정 policy/path configuration에서 effect가 허용됨
- scenario가 현재 PBEA abstraction만으로 명확히 정의되지 않음

어느 결과든 raw native evidence와 함께 보고한다.

실험 결과를 논문 claim에 맞게 조작하지 않는다.

TOCTOU를 구현할 경우 실제 race exploitation이 아닌 controlled deterministic probe를 우선한다.

---

# 11. Task I — Artifact manifest 및 자동 보고

모든 최종 artifact에 SHA-256 digest를 생성한다.

Manifest에는 최소 다음을 포함한다.

```text
source commit
build profile
OS version
experiment date
raw evidence hashes
benchmark data hashes
boundary-test hashes
validator version/hash
report generator version/hash
generated CSV hashes
generated LaTeX table hashes
```

다음 구조의 자동 생성 결과를 권장한다.

```text
generated/
    scenario_matrix.csv
    family_metrics.csv
    aggregate_metrics.csv
    s0_latency.csv
    startup_latency.csv
    boundary_results.csv

    scenario_matrix.tex
    family_metrics.tex
    s0_latency.tex
    boundary_results.tex
```

논문에 들어갈 모든 실험 숫자는 이 pipeline을 통해 생성 가능해야 한다.

---

# 12. Task J — 기존 internal TODO 제거를 위한 결과 파일 생성

현재 manuscript에는 S0 benchmark를 생성해야 한다는 TODO가 남아 있다.

이번 작업에서는 manuscript를 직접 수정하지 말고 대신 다음 파일을 생성한다.

```text
evaluation/revision_inputs.md
```

이 파일에는 논문 수정 단계에서 사용할 수 있도록 다음을 요약한다.

1. frozen source commit
2. 1080-record corpus validation status
3. B0/B1/B2/P scenario results
4. effect-family metrics
5. S0 benchmark
6. startup benchmark
7. boundary-test results
8. artifact paths
9. SHA-256 manifest
10. 기존 810-record 결과와 달라진 값

---

# 13. Regression / quality checks

최종 evidence를 freeze하기 전에 최소 다음을 수행한다.

## Linux/WSL development-side checks

```bash
cargo fmt --check
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

프로젝트에 이미 존재하는 architecture/policy/evidence validation tests도 모두 실행한다.

## OpenBSD native checks

- release build 성공
- OpenBSD backend 활성화 확인
- no-op sandbox fallback 불가 확인
- `unveil` probe 확인
- `pledge` probe 확인
- endpoint probe 확인
- fail-closed startup 확인

---

# 14. 반드시 피해야 할 작업

이번 작업 중 다음을 하지 말 것.

1. 논문 결과에 맞도록 scenario expected result를 hard-code하지 말 것.
2. B2를 구현하기 위해 Full-PBEA의 보안 기능을 약화하지 말 것.
3. B0/B1/P의 semantics를 불필요하게 변경하지 말 것.
4. `poa-core`의 domain-neutral transition semantics를 B2 때문에 재설계하지 말 것.
5. 기존 810-record 결과와 새로운 결과를 혼합하지 말 것.
6. manual spreadsheet calculation을 최종 논문 숫자로 사용하지 말 것.
7. latency benchmark에 process startup/intentional S3 termination 비용을 정상 S0 latency처럼 포함하지 말 것.
8. adaptive test에 실제 secret, external attack target, production endpoint를 사용하지 말 것.
9. 결과가 예상 hypothesis와 다르다는 이유로 fixture를 임의 변경하지 말 것.
10. unrelated refactoring, crate rename, API cleanup을 이번 작업에 포함하지 말 것.

이번 작업은 **논문 실험의 validity 보강**이 목적이지 repository modernization 작업이 아니다.

---

# 15. 최종 완료 조건

다음 조건을 모두 만족해야 작업 완료로 판단한다.

## Implementation

- [ ] `RuntimeOnly` mode 추가
- [ ] closed mode validation 4-mode로 확장
- [ ] B2 runtime confinement 적용
- [ ] B2에서 transition/digest semantics 비활성화 확인
- [ ] 기존 B0/B1/P regression 통과

## Comparative experiment

- [ ] B0/B1/B2/P × S0–S8 × 30 실행
- [ ] 총 1080 records 확보
- [ ] 전체 record 동일 frozen commit
- [ ] validator 100% 통과
- [ ] 4개 raw JSONL 생성
- [ ] SHA-256 manifest 생성

## Metrics

- [ ] State-integrity 결과 분리
- [ ] S2–S4 capability containment 분리
- [ ] S8 policy-binding 결과 분리
- [ ] S5 fail-closed 결과 분리
- [ ] S6 outcome/quarantine 결과 분리
- [ ] S0 benign preservation 분리
- [ ] aggregate MESR secondary metric 생성

## Benchmark

- [ ] startup timing 별도 측정
- [ ] steady-state S0 benchmark 별도 수행
- [ ] 최소 P50/P95/P99/mean/stddev 생성
- [ ] B0 대비 P overhead 자동 계산
- [ ] benchmark raw data 보존

## Boundary validation

- [ ] allowed-endpoint boundary test
- [ ] filesystem/symlink adaptive probe 가능성 검증 및 수행
- [ ] 결과를 success/failure로 숨기지 않고 그대로 기록

## Reproducibility

- [ ] raw evidence
- [ ] raw benchmark
- [ ] validator
- [ ] reporting scripts
- [ ] generated CSV
- [ ] generated LaTeX
- [ ] manifest
- [ ] execution commands
- [ ] `revision_inputs.md`

모두 repository 내에서 추적 가능해야 한다.

---

# 16. 완료 후 Codex가 제출할 최종 보고 형식

작업 완료 후 다음 순서로 보고할 것.

## A. Implementation Changes

변경된 files 및 각 변경 이유.

## B. Frozen Revision

최종 experiment source commit.

## C. Regression Status

`cargo test`, `clippy`, OpenBSD native checks.

## D. 4-Mode Evaluation

B0/B1/B2/P × S0–S8의 결과 matrix.

## E. Key Symmetry Result

특히 다음 세 항목을 명시한다.

- B1에서 S1과 S2–S4가 어떻게 달라지는가
- B2에서 S1과 S2–S4가 어떻게 달라지는가
- P에서 두 effect family가 어떻게 달라지는가

## F. S0 Benchmark

B0/B1/B2/P의 P50/P95/P99 및 B0 대비 overhead.

## G. Boundary Tests

allowed endpoint 및 adaptive filesystem probe의 실제 관측 결과.

## H. Artifact Validation

raw data 수, hash, validator 결과.

## I. Unexpected Findings

예상 hypothesis와 다른 모든 결과.

**예상과 다른 결과를 숨기거나 자동으로 수정하지 말고 반드시 별도 항목으로 보고할 것.**

---

## 최종 연구 목적

이번 개발의 목적은 Full-PBEA가 단순히 더 많은 방어 기능을 켠 configuration이기 때문에 결과가 좋아진다는 것을 보여주는 것이 아니다.

최종적으로 실험에서 보여야 할 구조는 다음과 같다.

```text
                  State integrity     Runtime confinement
B0 Access-only          ×                     ×
B1 Transition-only      ✓                     ×
B2 Runtime-only         ×                     ✓
P  Full-PBEA            ✓                     ✓
```

그리고 정상 S0 workload에서는 Full-PBEA가 실제로 동작하면서 그 추가 execution cost를 정량적으로 측정할 수 있어야 한다.

이 대칭적 ablation과 정상 workload benchmark가 확보되면 PBEA의 핵심 실험 주장은 다음과 같이 강화될 수 있다.

> Transition integrity and runtime-capability confinement protect different classes of post-authorization effects. Neither layer substitutes for the other in the evaluated system; Full-PBEA binds both under one execution policy while preserving the evaluated benign operation at a measurable runtime cost.