Claude의 리뷰와 현재 업로드한 `_46_PBEA_19p.tex`를 대조해 보면, **1차 수정 방향은 맞습니다.** 특히 Claude가 종합평가에서 가장 먼저 지적한 “Implementation 절 부재”는 현재 `Reference Implementation` 절로 상당히 충실하게 보강되었고, Rust workspace, policy resolution/JCS, OpenBSD `pledge`/`unveil`, evidence instrumentation, verification까지 포함되어 있습니다.  또한 원고는 더 이상 ICT Express용 `elsarticle`이 아니라 `IEEEtran`을 사용하고 있으므로, Claude의 (2) “ICT Express와 19페이지 분량의 불일치” 문제도 원고 차원에서는 제거됐습니다. 

다만 지금부터는 **문장 수정이 아니라 실험 설계의 보강이 가장 중요합니다.** Claude 리뷰에서 남아 있는 가장 강한 공격점은 정확히 이것입니다. Claude도 self-referential ablation을 “리뷰어 최대 공격 지점”으로 보았습니다. 

## 1. 현재 Claude 지적의 반영 상태

| Claude 지적                         | 현재 상태          | 제가 권하는 조치                      |
| --------------------------------- | -------------- | ------------------------------ |
| Implementation 절 없음               | **해결**         | 유지                             |
| ICT Express/19p 불일치               | **해결된 것으로 보임** | 최종 목표 IEEE 저널 공식 template만 재확인 |
| Artifact 공개                       | **부분 미해결**     | Code/Data Availability 추가      |
| B0/B1/P self-referential ablation | **미해결**        | **B2 Runtime-only 추가**         |
| S0 실제 latency                     | **미해결**        | **반드시 새 실험**                   |
| 최신 학술문헌 부족                        | **미해결**        | 2020+ peer-reviewed 문헌 보강      |
| Process Trust 정식화                 | **부분 해결**      | Problem Model로 이동하고 SO와 연결     |
| MESR denominator 문제               | **미해결**        | effect class별 metric 분리        |
| 정책 작성 비용                          | **미해결**        | policy-complexity 표 추가         |
| Linux mapping                     | 부분 언급          | 비평가 설계표로 보강 가능                 |
| caveat 반복                         | **아직 많음**      | Limitations 중심으로 통합            |
| minor LaTeX 문제                    | 상당수 남음         | 투고 전 일괄 정리                     |

---

# 2. 가장 먼저 해야 할 수정: B2를 추가하십시오

이 부분은 Claude 의견에 전적으로 동의합니다.

현재 실험은

**B0 Access-only → B1 Transition-only → P Full-PBEA**

로 구성됩니다. 현재 원고도 이 세 mode만 명시합니다. 

문제는 이 설계가 다음 한 방향만 증명한다는 것입니다.

> Transition control만으로는 S2–S4 runtime effect를 막을 수 없다 → 따라서 runtime confinement가 추가로 필요하다.

현재 ablation도 정확히 그렇게 해석하고 있습니다. 

그런데 논문의 핵심 주장은 사실 더 강합니다.

> **Transition integrity와 runtime confinement는 서로 다른 보안 경계를 담당하며 어느 한쪽만으로는 PBEA의 Process Trust를 구성할 수 없다.**

그렇다면 반대 방향도 보여주어야 합니다.

### B2 — Runtime-only 또는 Runtime-Confinement-only

B2에서는 다음 정도가 적절합니다.

| Mechanism            | B0 | B1 | **B2** |  P |
| -------------------- | -: | -: | -----: | -: |
| Admission            |  ✓ |  ✓ |      ✓ |  ✓ |
| Candidate isolation  |  × |  ✓ |      × |  ✓ |
| Invariants           |  × |  ✓ |      × |  ✓ |
| Digest binding       |  × |  ✓ |      × |  ✓ |
| Endpoint restriction |  × |  × |      ✓ |  ✓ |
| `unveil`             |  × |  × |      ✓ |  ✓ |
| `pledge`             |  × |  × |      ✓ |  ✓ |
| Outcome semantics    |  × |  ✓ |   최소/× |  ✓ |

여기서 예상되는 가장 중요한 결과는:

* B1: S1은 막지만 S2–S4는 못 막음
* B2: S2–S4는 막지만 S1은 못 막음
* P: 둘 다 막음

입니다.

이 결과가 나오면 PBEA의 핵심 메시지가

> “P가 B1보다 좋다”

에서

> **“state-transition integrity와 runtime confinement는 orthogonal security controls이며 PBEA는 이 둘을 동일한 operation policy에 binding한다.”**

로 바뀝니다.

이 차이는 상당히 큽니다.

현재 원고 스스로도 sandbox-only가 없다는 것을 Limitations에서 인정하고 있습니다.  따라서 저는 **Claude 리뷰 전체에서 B2 추가를 가장 중요한 수정사항으로 봅니다.**

---

# 3. S0 latency는 반드시 실제 결과로 교체해야 합니다

이 부분은 선택사항이 아닙니다.

현재 원고에는 아직 다음 내부 TODO가 그대로 존재합니다.

> “A benign-only S0 latency table should be generated … before the final manuscript artifact is frozen.”



Limitations에도 같은 TODO가 다시 남아 있습니다. 

현재 latency table은 B0/B1/P 전체 mixed scenario를 합친 결과인데, P의 P95와 mean이 S3 child process와 의도적인 `pledge` termination 때문에 커진다는 것을 논문 스스로 설명하고 있습니다. 

따라서 최종본에서는 **성능 평가를 두 종류로 분리하는 것이 좋습니다.**

**Primary performance result:** 정상 S0 요청만 반복한 steady-state benchmark입니다. B0/B1/B2/P 각각에 대해 동일 프로세스에서 warm-up 후 반복 수행하고 Median, P95, P99를 제시합니다. 가능하다면 throughput도 추가하십시오.

**Secondary diagnostic result:** 현재의 mixed-scenario latency입니다. 이것은 “attack/evaluation harness cost”로 이름을 바꾸고 부록이나 보조 표로 내려도 됩니다.

그러면 RQ5도 단순히 “실험 harness의 cost가 얼마인가?”가 아니라,

> “What incremental execution cost does PBEA impose on policy-conforming steady-state operations?”

으로 훨씬 강해집니다.

---

# 4. Process Trust 정의는 더 앞으로 옮겨야 합니다

Claude는 Process Trust 정의가 너무 늦게 나온다고 지적했습니다. 이 부분은 1차 수정에서 어느 정도 개선됐습니다.

현재 `Trust_process(q)` 정의는 Discussion이 아니라 Architecture 마지막의 Enforcement Summary에 이미 들어가 있습니다. 

따라서 Claude가 본 이전 버전보다 좋아졌습니다.

그러나 저는 **한 단계 더 이동시키는 것이 좋다고 봅니다.**

현재 논문 제목이

**From Access Trust to Process Trust**

이므로 Process Trust는 architecture 결과가 아니라 **Problem Model에서 정의되는 연구대상**이어야 합니다.

현재 Problem Model에는 이미

$$
E_D(q)\models P_I(o)
$$

와

$$
E_R(q)\subseteq P_R(o)
$$

라는 두 핵심 조건이 정의되어 있습니다. 

그 바로 다음에 Process Trust를 정의하십시오.

개념적으로는 다음 구조가 더 명확합니다.

$$
ProcessTrust(q)
=
StateConform(q)
\land RuntimeConform(q)
\land PolicyBound(q)
\land OutcomeConsistent(q)
$$

이렇게 하면 논문 전체가

**Access Trust → Process Trust definition → Security Objectives → PBEA mechanisms → Experiments**

로 연결됩니다.

현재처럼 Architecture 끝에서 처음 formal definition이 나오면 “PBEA를 만들고 나서 Process Trust라는 개념을 붙였다”는 인상을 줄 수 있습니다.

---

# 5. 특히 S8을 별도의 Policy-Binding objective로 분리하는 것이 좋습니다

여기에서 현재 원고에 조금 더 중요한 논리적 문제가 있습니다.

현재 T8 “Wrong effective-policy digest”는 Threat-to-Objective table에서 **SO1, SO4**에 매핑되어 있습니다. 

그런데 SO1은 State Integrity이고 SO4는 Outcome Separation입니다.

**policy digest mismatch는 본질적으로 둘 중 어느 것도 아닙니다.**

PBEA의 중요한 contribution 중 하나가

> 동일한 effective policy를 transition, runtime enforcement, evidence에 binding한다

는 것이라면 이것은 독립된 보안 목표로 만드는 편이 더 자연스럽습니다.

예를 들어:

**SO5 — Policy-Binding Consistency**

그리고 현재 SO5 Benign Preservation을 SO6로 이동합니다.

그러면 S8 → SO5가 됩니다.

이렇게 해야 앞에서 정의한 Process Trust의

`Evidence(q) ~ h_P`

조건도 실제 Security Objective 및 실험과 연결됩니다. 현재 Process Trust 정의에는 evidence-policy binding이 들어가 있지만, Security Objectives에는 정확히 대응하는 항목이 없습니다. 

이 수정은 논문의 이론적 완성도를 상당히 높일 수 있습니다.

---

# 6. MESR 180/180 → 90/180 → 0/180을 메인 headline에서 한 단계 내리십시오

Claude의 이 지적도 타당합니다.

현재 aggregate result는 모든 heterogeneous scenario를 하나로 합쳐:

* B0 = 180/180
* B1 = 90/180
* P = 0/180

을 MESR로 보고합니다. 

하지만 S1 invariant violation과 S2 filesystem escape와 S8 digest mismatch는 **보안 의미가 서로 다릅니다.**

따라서 최종 논문에서는 aggregate MESR을 없앨 필요까지는 없지만 **secondary summary metric**으로 내리는 편이 좋습니다.

메인 결과는 오히려 다음처럼 분해하십시오.

| Effect family           | 대표 scenario | 주 metric                           |
| ----------------------- | ----------- | ---------------------------------- |
| State integrity         | S1, S7      | Invalid-state propagation rate     |
| Runtime capabilities    | S2–S4       | Capability containment/escape rate |
| Policy binding          | S8          | Digest-mismatch acceptance rate    |
| Fail-closed startup     | S5          | FCR                                |
| Trust/outcome semantics | S6          | Quarantine/non-propagation         |
| Benign operation        | S0          | BRSR                               |

이렇게 하면 reviewer가 “왜 서로 다른 attack을 하나의 분모로 더했나?”라고 공격하기 어려워집니다.

또 현재 `180/180=100%`와 `90/180=50%`를 별도의 display equation으로 사용한 부분은 Claude 말대로 inline으로 처리하는 것이 낫습니다. 

---

# 7. Wilson CI는 삭제할 필요는 없지만 비중을 크게 낮추는 것이 좋습니다

현재 원고는 이미 상당히 정직하게 한계를 인정하고 있습니다.

30회의 반복은 real-world attack population에서 독립 추출한 sample이 아니라 **deterministic fixture의 반복 실행**이라고 명시되어 있습니다. 

이 경우 저는 Wilson CI를 메인 증거처럼 보여주는 것을 권하지 않습니다.

30회 반복의 의미는 통계적 추론보다는:

**reproducibility / stability of observed mechanism behavior**

입니다.

따라서 본문에서는 exact count와 scenario-level outcome을 중심으로 하고 Wilson CI는 부록으로 이동하거나 아주 짧게 남기는 것이 더 안전합니다.

---

# 8. Adaptive adversary는 “별도 boundary experiment”로 추가하는 것이 가장 좋습니다

Claude는 symlink/TOCTOU나 allowed endpoint를 통한 exfiltration 같은 adaptive adversary를 제안했습니다. 

저는 이것을 기존 MESR에 섞는 것보다 **Claim-Boundary Stress Test**라는 별도 subsection으로 두는 것을 추천합니다.

예를 들어:

**BT1 — Policy-conforming endpoint abuse:** endpoint가 정책상 허용되어 있으면 PBEA는 데이터 전송을 막지 않아야 합니다.

이것이 성공하면 오히려 좋은 결과입니다.

> PBEA does not infer malicious intent inside an explicitly permitted capability.

현재 Limitations도 이미 allowed endpoint/file abuse를 막는다고 주장하지 않습니다. 

두 번째로 여력이 있으면 **symlink/TOCTOU boundary test**를 추가하되, 이것은 OpenBSD `unveil` semantics를 정확히 확인한 후 설계하는 것이 좋습니다.

이런 “일부 공격이 성공하는 실험” 하나가 포함되면 논문의 bounded claim이 단순한 disclaimer가 아니라 **실험적으로 검증된 claim boundary**가 됩니다.

---

# 9. 최신 문헌 보강은 필요하지만 Claude의 “각 영역 5–10건”은 과합니다

Claude는 최신 ZTA, eBPF/Landlock, IFC, attestation, transactional isolation 등을 각각 5–10건 추가하라고 권했습니다. 

방향은 맞지만 **그 숫자까지 따를 필요는 없습니다.**

현재 Related Work가 이미 상당히 길기 때문에 저는 총 **12–15편 정도의 엄선된 peer-reviewed 논문**을 추가하는 것이 더 좋다고 봅니다.

우선순위는:

1. modern ZTA / continuous authorization
2. information-flow control
3. runtime/container/eBPF/Landlock enforcement
4. policy binding / provenance / attestation / in-toto 계열
5. transactional or state-isolation security

입니다.

특히 Positioning Table에는 기존 ZTA/UCON/DbC/RASP/Sandboxing에 더해 **Information-Flow Control**과 **Attestation/Provenance/Policy Binding** 두 행 정도를 추가하는 것이 효과적입니다.

현재 Related Work는 NIST guidance가 주요 최신 자료이고, compartmentalization 쪽 peer-reviewed 인용도 Wedge, Capsicum, ACES 등 비교적 오래된 연구가 중심입니다.  

따라서 이 지적은 여전히 유효합니다.

---

# 10. Implementation은 잘 추가됐지만 Artifact Availability가 아직 빠져 있습니다

Claude의 (1)은 단순히 Implementation 절만 추가하라는 것이 아니라 **재현 가능한 artifact 접근 방법**까지 포함한 지적이었습니다. 

현재 논문은 commit `1bcfa8b`와 내부 `raw/access-only.jsonl`, `raw/transition-only.jsonl`, `raw/full-pbea.jsonl`을 명시합니다. 

그러나 이것만으로 reviewer가 데이터를 받을 수는 없습니다.

따라서 최종 투고본에는 최소한 다음이 필요합니다.

**Artifact Availability / Data and Code Availability**

여기에 code, execution policy, raw JSONL evidence, manifest/hash, reporting scripts를 어느 repository/DOI에서 받을 수 있는지를 명시해야 합니다.

아직 double-blind 심사라면 anonymous artifact repository를 사용하면 됩니다.

Implementation 절 자체는 지금 정도면 오히려 상당히 좋습니다.

---

# 11. 정책 작성 비용은 “작성 시간”보다 객관적 complexity를 측정하십시오

Claude는 정책 작성 공수를 제시하라고 했습니다. 

그런데 이미 개발한 정책에 대해 사후적으로 “3시간 걸렸다”와 같은 수치를 만들면 신뢰성이 약합니다.

대신 부록에 다음을 정량화하는 것을 권합니다.

`policy bytes`, `LOC`, `number of fields`, `filesystem rules`, `endpoint rules`, `process constraints`, `inheritance depth`, `required-resource count`, `policy-resolution/digest time`.

이것이 훨씬 객관적인 **policy administration complexity proxy**입니다.

---

# 12. Linux mapping은 유용하지만 “실증 결과”로 보이면 안 됩니다

현재 원고는 Linux backend가 stub이고 Landlock/seccomp은 future extension이라고 명확하게 한정하고 있습니다. 

따라서 Claude가 말한 mapping table을 추가한다면 제목부터:

**Potential mapping of PBEA runtime policy to non-evaluated Linux mechanisms**

정도로 해야 합니다.

예를 들어 filesystem → Landlock, syscall/process class → seccomp, resource constraints → cgroup, endpoint control → application/eBPF 계열처럼 보여줄 수 있지만 반드시 **Not implemented / Not evaluated**라고 표시하십시오.

이것은 B2와 S0 benchmark보다 우선순위가 낮습니다.

---

# 13. Caveat 반복은 실제로 줄이는 것이 좋습니다

현재 bounded claim은 Abstract, Introduction, Evaluation Summary, Limitations, Conclusion 등에서 반복됩니다. 예를 들어 Abstract에도 universal malware prevention 등을 주장하지 않는다는 문장이 있고,  Evaluation Summary에서도 거의 동일한 범위를 다시 적고 있습니다. 

권장 구조는:

**Abstract:** 1문장
**Introduction:** 1문장
**Limitations:** 상세 설명
**Conclusion:** 짧은 한정구

정도입니다.

현재처럼 모든 section에서 반복하면 “주장을 매우 조심한다”기보다 오히려 “저자도 결과를 신뢰하지 못하는가?”라는 느낌을 줄 수 있습니다.

---

# 14. Claude의 Minor 지적들은 대부분 아직 그대로 남아 있습니다

이것들은 마지막에 일괄 수정하면 됩니다.

현재 `tab:mode_configuration`에서는 `\tnote{a}`와 `tablenotes`를 쓰면서 실제로 `threeparttable` 환경으로 감싸지 않았습니다.  따라서 실제로 `\begin{threeparttable} ... \end{threeparttable}`를 추가해야 합니다.

또한 다음은 반드시 정리하십시오.

* `\usepackage{url}`과 `tikz`가 중복 로드되어 있습니다. 
* `\usepackage[hidelinks]{}`는 명백히 이상합니다. 의도가 hyperlink라면 `\usepackage[hidelinks]{hyperref}`인지 확인해야 합니다. 
* 한국어 source comment와 `kotex`는 영문 투고본이라면 제거하십시오. 
* `"The generated artifact originally labels this quantity CER"` 문장은 반드시 삭제하십시오. 이는 연구 결과가 아니라 내부 개발 이력입니다. 
* `"Historical source packages retain the poa-* prefix..."`도 Introduction에서는 삭제하십시오.  crate 이름 자체는 Implementation에서 재현성을 위해 남겨도 됩니다.
* RQ1–RQ5가 Introduction과 Evaluation에 거의 두 번 완전히 나타납니다. Evaluation에서만 full wording을 두고 Introduction에서는 한 문장으로 줄이는 편이 좋습니다. 현재 Evaluation에서 다시 전체 RQ가 정의됩니다. 
* 현재 업로드된 bibliography 파일명은 `references(5).bib`인데 원고는 `\bibliography{references}`를 호출합니다. 실제 제출 package에서는 반드시 basename을 일치시키십시오. 
* IITP 과제번호도 실제 과제 표기와 최종 대조하십시오. 

---

# 제가 권하는 최종 수정 순서

가장 효율적인 순서는 다음입니다.

1. **Codex에서 B2 Runtime-only mode 구현 및 동일 scenario matrix 재실험**
2. **S0-only steady-state benchmark 수행**
3. **Process Trust 정의를 Sec. 3 Problem Model로 이동 + Policy-Binding SO 추가**
4. **MESR을 effect family별 metric으로 분해**
5. **Boundary stress test 1개 이상 추가**
6. **2020년 이후 peer-reviewed 관련연구 12–15편 보강**
7. Artifact Availability 및 policy-complexity table 추가
8. caveat/RQ 중복을 압축
9. LaTeX minor 오류를 일괄 수정

이 순서가 중요한 이유는 **1–5가 바뀌면 실험 수치와 논문의 논리 구조 자체가 바뀌기 때문**입니다. 반대로 문장 다듬기나 참고문헌 정리는 그 이후에 해도 됩니다.

현재 상태에서 제가 가장 중요하게 보는 세 가지는 **B2, S0 benchmark, Process Trust–Security Objective–Metric의 formal alignment**입니다. 이 세 가지를 반영하면 논문이 지금의 “잘 만든 PBEA prototype과 내부 ablation 보고서”에서 **“두 enforcement plane의 비대체성을 실험적으로 검증한 systems-security architecture 논문”**으로 한 단계 올라갑니다. Claude 리뷰의 핵심도 결국 그 부분을 요구하고 있다고 봅니다.
