# PBEA 논문 보강을 위한 추가 개발 및 재실험 계획서

본 계획서는 Claude AI Agent의 1차 리뷰(`claude_review.md`) 및 ChatGPT의 보강 분석(`background.md`)을 바탕으로 작성된 **"PBEA 논문 보강을 위한 추가 개발·재실험 작업지시서.md"**에 따른 구체적 개발, OpenBSD 7.9 실측 실험, 벤치마크 및 검증 자동화 절차를 정의합니다.

---

## 1. 핵심 목표 (Core Objectives)

1. **B2 (Runtime-only) Configuration 추가**:
   - Transition integrity와 Runtime confinement가 서로 대체 불가능한 독립적 보안 경계(Orthogonal & Non-substitutable Security Boundaries)임을 증명하는 대칭적 Ablation matrix 완성.
   - 기존 3-mode (B0, B1, P)에서 **4-mode (B0 Access-only, B1 Transition-only, B2 Runtime-only, P Full-PBEA)**로 확장.
2. **1080-Record Comparative Evaluation 재실험**:
   - `4 modes × 9 scenarios (S0–S8) × 30 iterations = 1080 records`
   - OpenBSD 7.9 Hyper-V 환경에서 네이티브 `pledge(2)`/`unveil(2)` 기반 재실험 수행 및 raw JSONL evidence 확보.
3. **정상 S0 Steady-State Latency & Startup Benchmark 신규 측정**:
   - Mixed-scenario 타이밍 대신 장기 실행 프로세스 기반 S0 정상 요청 반복 벤치마크(Warm-up 100회, 측정 1,000회 이상 × 5배치) 및 Startup 비용 분리 측정.
   - P50, P95, P99 오버헤드 산출 (`(P - B0) / B0 * 100`).
4. **Claim-Boundary / Adaptive-Adversary 실증 실험 (BT1, BT2)**:
   - BT1: 정책상 허용된 엔드포인트 전송(PBEA가 명시적 허용 범위 내의 악의적 의도를 자의적으로 추론하지 않음).
   - BT2: Filesystem Symlink/경로 경계 프로브(OpenBSD unveil 동작의 실제 경계 검증).
5. **Effect-Family 중심 메트릭 분해 및 자동화 산출물 생성**:
   - State Integrity (S1, S7), Runtime Capability Containment (S2, S3, S4), Policy Binding (S8), Fail-closed Startup (S5), Quarantine (S6), Benign Preservation (S0) 분리 보고.
   - Validator 4-mode 확장, CSV/LaTeX 테이블 자동 생성, SHA-256 Manifest 및 `evaluation/revision_inputs.md` 작성.

---

## 2. 사용자 검토 및 확인 필요 사항 (User Review Required)

> [!IMPORTANT]
> - **OpenBSD 원격 실행 및 동기화**: 본 작업은 Hyper-V OpenBSD 7.9 VM (`192.168.1.103`)으로 수정된 Rust 소스를 동기화하여 release 빌드 후 1080건의 실측 및 S0 벤치마크를 수행합니다.
> - **새로운 Frozen Commit 적용**: 기존 `1bcfa8b` (810건) 데이터와 새 B2 포함 1080건 데이터의 혼합을 방지하기 위해, B2 및 벤치마크 구현 완료 후 새 git commit을 freeze하여 모든 evidence에 기록합니다.

---

## 3. 세부 변경 사항 (Proposed Changes)

### Component 1: Rust Core & Verifier Implementation (`pbea/crates/`)

#### [MODIFY] [mode.rs](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/mode.rs)
- `VerifierMode` enum에 `RuntimeOnly` 추가:
  ```rust
  pub enum VerifierMode {
      AccessOnly,
      TransitionOnly,
      RuntimeOnly,
      FullPbea,
  }
  ```
- `VerifierMode::ALL = [AccessOnly, TransitionOnly, RuntimeOnly, FullPbea]`
- `policy_digest_required()`: `false` for `AccessOnly` and `RuntimeOnly`, `true` for `TransitionOnly` and `FullPbea`
- `transition_guards_enabled()`: `false` for `AccessOnly` and `RuntimeOnly`, `true` for `TransitionOnly` and `FullPbea`
- `runtime_constraints_enabled()`: `true` for `RuntimeOnly` and `FullPbea`, `false` for `AccessOnly` and `TransitionOnly`
- `validate_mode_policy()`: `RuntimeOnly`도 `FullPbea`와 마찬가지로 production mode, `OsBackend::Openbsd`, locked unveil table 요구.
- String 파싱/포맷: `"runtime-only"` 지원.

#### [MODIFY] [adversarial_probe.rs](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/bin/adversarial_probe.rs)
- B2 mode 동작 정의:
  - **S0 (Benign)**: Runtime confinement 하에서 동작, transition guard 비활성화, 직접 state 갱신 -> `success`, malicious_effect = false.
  - **S1 (Invariant violation amount=0)**: Transition invariant 검사 비활성화 -> 직접 도메인 상태 변경 성공 -> `success`, malicious_effect_succeeded = true (상태 오염 발생).
  - **S2 (Unveil file escape)**: `unveil` 활성화 -> 외부 파일 읽기 실패 -> `reject` (errno 기록), malicious_effect_succeeded = false.
  - **S3 (Undeclared child execution)**: `pledge` 활성화 -> sandboxed-exec 실행 시 child 프로세스 시그널 종료 -> `terminated` (signal 기록), malicious_effect_succeeded = false.
  - **S4 (Disallowed endpoint)**: Application endpoint allowlist 활성화 -> 미인가 loopback 연결 차단 -> `reject` (errno 기록), malicious_effect_succeeded = false.
  - **S5 (Invalid startup)**:
    - Malformed policy: startup 실패 -> `startup-failure`.
    - Missing required resource: `StartupEnforcement::prepare` 실패 -> `startup-failure`.
  - **S6 (Repeated violation)**: PBEA 격리/quarantine 상태 전환 미적용 -> `success`, quarantine 미발생.
  - **S7 (Candidate creation fault injection)**: Transactional candidate isolation 부재 -> 직접 변이 실행 -> `success` / 상태 누출 관측.
  - **S8 (Wrong policy digest)**: Digest binding 미적용 -> 변조된 digest 요청도 거부 없이 처리 -> `success`, malicious_effect_succeeded = true.

#### [NEW] [s0_benchmark.rs](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/bin/s0_benchmark.rs)
- S0 Steady-State & Startup 전용 고정밀 벤치마크 바이너리:
  - Phase 1 (Startup): Policy 파싱, JCS canonicalization, digest 계산, resource 준비, unveil/pledge 설치 시간 측정.
  - Phase 2 (Steady-State): Long-lived verifier 프로세스 상태에서 100회 warm-up 후 5 배치 × 1,000회 S0 트랜잭션 실행 시간(µs/ns 단위) 측정.
  - 모드별 (B0, B1, B2, P) raw latency JSON 및 통계치(Min, P50, P95, P99, Max, Mean, Stddev) 출력.

#### [NEW] [boundary_probe.rs](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/bin/boundary_probe.rs)
- Claim-Boundary / Adaptive-Adversary 검증 바이너리:
  - **BT1 (Allowed endpoint misuse)**: 허용된 loopback 포트로 정상 marker 전송 -> Full-PBEA에서 허용됨을 실증(PBEA는 명시적 허용 정책 내 악의적 의도를 추론하지 않음).
  - **BT2 (Filesystem symlink probe)**: 허용 경로 내 synthetic symlink를 통해 외부 파일 접근 시도 -> OpenBSD unveil의 실제 커널 레벨 제약 관측 및 네이티브 evidence 기록.

---

### Component 2: Evaluation Framework & Validation Scripts (`pbea/evaluation/comparative/`)

#### [MODIFY] [evidence.schema.json](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/evidence.schema.json)
- `mode` enum에 `"runtime-only"` 추가.

#### [MODIFY] [validate_records.py](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/validate_records.py)
- `MODES = ("access-only", "transition-only", "runtime-only", "full-pbea")`
- `expected(mode, scenario, iteration)` 4-mode 규칙 확장.
- 1080건 완전성 검증 (`len(records) == 1080`, `len(cells) == 1080`).

#### [MODIFY] [run_matrix.py](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/run_matrix.py) & [run_matrix_openbsd.sh](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/run_matrix_openbsd.sh)
- 4-mode (B0, B1, B2, P) 루프 및 `runtime-only.jsonl` 출력 지원.

#### [MODIFY] [compute_security_metrics.py](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/compute_security_metrics.py)
- Effect Family별 지표 분해 계산:
  - `F1 State Integrity (S1, S7)`: Invalid-state propagation rate, SIVR
  - `F2 Capability Containment (S2, S3, S4)`: CCR (개별 S2, S3, S4 및 결합)
  - `F3 Policy Binding (S8)`: Policy-Binding Violation Acceptance Rate
  - `F4 Fail-Closed Startup (S5)`: FCR (malformed vs missing resource)
  - `F5 Outcome / Quarantine Semantics (S6)`: Quarantine rate
  - `F6 Benign Preservation (S0)`: BRSR
  - `F7 Aggregate MESR`: Secondary summary metric

#### [MODIFY] [generate_tables.py](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/generate_tables.py) & [generate_report.py](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/generate_report.py)
- 4-mode 및 분해 메트릭에 맞추어 CSV 및 LaTeX 테이블 자동 생성:
  - `scenario_matrix.csv` / `scenario_matrix.tex`
  - `family_metrics.csv` / `family_metrics.tex`
  - `aggregate_metrics.csv`
  - `s0_latency.csv` / `s0_latency.tex`
  - `startup_latency.csv`
  - `boundary_results.csv` / `boundary_results.tex`

#### [MODIFY] [test_evidence.py](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/tests/test_evidence.py)
- 4-mode evidence unit test 추가.

---

### Component 3: Execution, Artifact Manifest & Reports

#### [NEW] `pbea/evaluation/runs/pbea_4mode_v2/` 및 `pbea/docs/work_reports/202_pbea_rev_round_1/raw/`
- `access-only.jsonl` (270 records)
- `transition-only.jsonl` (270 records)
- `runtime-only.jsonl` (270 records)
- `full-pbea.jsonl` (270 records)
- `s0_benchmark.json` & `startup_benchmark.json`
- `boundary_results.json`
- `manifest.sha256`

#### [NEW] [revision_inputs.md](file:///d:/_Work/goat_bank/pbea/evaluation/revision_inputs.md)
- 논문 수정 시 즉시 인용할 수 있는 수치와 요약문 정리.

#### [NEW] `pbea/docs/work_reports/202_pbea_rev_round_1/` 보고서 생성
- `comparative_evaluation_report_v2.md`
- `s0_steady_state_overhead_report.md`
- `claim_boundary_report.md`

---

## 4. 검증 계획 (Verification Plan)

### Step 1. Linux/WSL2 개발 환경 로컬 검증
- Rust 유닛/통합 테스트:
  ```bash
  cargo test --workspace
  cargo fmt --check
  cargo clippy --workspace --all-targets -- -D warnings
  ```
- Python 검증 스크립트 테스트:
  ```bash
  pytest evaluation/comparative/tests
  ```

### Step 2. OpenBSD 7.9 VM 실측 및 Matrix 실행
- 소스 코드 패키징 및 OpenBSD VM으로 rsync/SFTP 전송.
- OpenBSD에서 release 빌드:
  ```sh
  cargo build --release -p poa-verifier-example --bin adversarial_probe --bin controlled_helper --bin s0_benchmark --bin boundary_probe
  ```
- 1080건 matrix 실행 (`run_matrix_openbsd.sh`).
- S0 steady-state 및 startup benchmark 실행.
- Boundary test (BT1, BT2) 실행.
- 결과 JSONL 및 벤치마크 데이터를 로컬로 수신.

### Step 3. Validator 및 Report 생성 파이프라인 검증
- Validator 실행:
  ```bash
  python3 evaluation/comparative/validate_records.py docs/work_reports/202_pbea_rev_round_1/raw/*.jsonl
  ```
  (1080건 100% 통과 확인)
- 메트릭 계산 및 테이블/보고서 자동 생성.
- SHA-256 Manifest 생성 및 무결성 검증.

---

## 5. 실행 승인 요청

위 계획에 따라 Rust 코드 수정 및 4-mode 확장, OpenBSD 7.9 실측 재실험, S0 벤치마크, 경계 테스트, 테이블 생성 파이프라인 작업을 진행하겠습니다. 계획을 검토해 주시고 승인해 주시면 즉시 착수하겠습니다.
