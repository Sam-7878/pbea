# PBEA 논문 보강을 위한 추가 개발·재실험 결과 보고서

본 보고서는 작업지시서(**"PBEA 논문 보강을 위한 추가 개발·재실험 작업지시서.md"**)에 명시된 모든 개발, OpenBSD 7.9 실측 재실험(1,080건), S0 정상 워크로드 벤치마크(5,000건), 적응형 경계 프로브(BT1, BT2) 및 메트릭 분해 결과를 요약합니다.

---

## 1. 주요 구현 변경 사항 (Implementation Changes)

| 컴포넌트 | 변경 파일 | 변경 목적 및 내용 |
|---|---|---|
| **Verifier Mode** | [`mode.rs`](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/mode.rs) | `VerifierMode::RuntimeOnly` (B2) 열거형 추가, 4-mode 확장, digest/transition 비활성화 및 runtime constraint 활성화 정의 |
| **Comparative Probe** | [`adversarial_probe.rs`](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/bin/adversarial_probe.rs) | S0–S8 전 시나리오에 대해 B2 (Runtime-only) 분기 구현 및 증거 레코드 필드 매핑 |
| **S0 Latency Benchmark** | [`s0_benchmark.rs`](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/bin/s0_benchmark.rs) | [NEW] 1회성 데몬 시작 비용 및 Long-lived 프로세스 기반 S0 steady-state 5,000회 고정밀 벤치마크 바이너리 |
| **Boundary Probe** | [`boundary_probe.rs`](file:///d:/_Work/goat_bank/pbea/crates/poa-verifier-example/src/bin/boundary_probe.rs) | [NEW] 허용 엔드포인트 전송(BT1) 및 unveil 심볼릭 링크 경로 순회(BT2) 경계 실증 바이너리 |
| **Schema & Validation** | [`evidence.schema.json`](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/evidence.schema.json)<br>[`validate_records.py`](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/validate_records.py) | 4-mode 1080건 완결성 및 의미론적 fail-closed 검증기 확장 |
| **Metrics & Reporting** | [`compute_security_metrics.py`](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/compute_security_metrics.py)<br>[`generate_tables.py`](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/generate_tables.py)<br>[`generate_report.py`](file:///d:/_Work/goat_bank/pbea/evaluation/comparative/generate_report.py) | Effect Family별 지표 분해 (State Integrity, Capability Containment, Policy Binding, Fail-closed, Quarantine, Benign), LaTeX/CSV 자동 생성 |

---

## 2. Frozen Evaluation Revision

- **Evaluation Commit Hash**: `62229cd31ad1915cdd850fe3cfd670cddf208d0c` (Short: `62229cd`)
- **실측 환경**: Hyper-V OpenBSD 7.9 (GENERIC.MP#449 amd64 / Rust 1.94.1)
- **평가 코퍼스**: 총 **1,080 records** (`4 modes × 9 scenarios × 30 iterations`)

---

## 3. 회귀 테스트 및 검증 현황 (Regression & Quality Checks)

```text
[✓] cargo fmt --all -- --check             : PASSED (코드 포맷 100% 일치)
[✓] cargo clippy --workspace --all-targets  : PASSED (0 warnings, 0 errors)
[✓] cargo test --workspace                 : PASSED (67 unittests + outcome tests pass)
[✓] pytest evaluation/comparative/tests    : PASSED (8/8 Python tests pass)
[✓] validate_records.py (1080 records)     : PASSED ({"cells": 1080, "records": 1080, "status": "valid"})
```

---

## 4. 4-Mode 시나리오 결과 매트릭스 (S0–S8)

| 시나리오 ID | 시나리오 설명 | Access-only (B0) | Transition-only (B1) | Runtime-only (B2) | Full-PBEA (P) |
|---|---|:---:|:---:|:---:|:---:|
| **S0** | Benign authorized operation | `success` (0/30) | `commit` (0/30) | `success` (0/30) | `commit` (0/30) |
| **S1** | Post-auth invariant violation | `success` (30/30) | `reject` (0/30) | `success` (30/30) | `reject` (0/30) |
| **S2** | Policy-external file read | `success` (30/30) | `success` (30/30) | `reject` (0/30) | `reject` (0/30) |
| **S3** | Undeclared helper execution | `success` (30/30) | `success` (30/30) | `terminated` (0/30) | `terminated` (0/30) |
| **S4** | Disallowed loopback connect | `success` (30/30) | `success` (30/30) | `reject` (0/30) | `reject` (0/30) |
| **S5** | Invalid runtime startup | `success` (0/30) | `startup-failure` (0/30) | `startup-failure` (0/30) | `startup-failure` (0/30) |
| **S6** | Repeated valid-actor violation | `success` (30/30) | `quarantine` (0/30) | `success` (30/30) | `quarantine` (0/30) |
| **S7** | Candidate creation fault | `success` (0/30) | `abort` (0/30) | `success` (0/30) | `abort` (0/30) |
| **S8** | Mismatched policy digest | `success` (30/30) | `reject` (0/30) | `success` (30/30) | `reject` (0/30) |

*(괄호 `x/30`은 30회 결정론적 반복 실행 중 악의적 공격/비정상 효과가 성공한 횟수)*

---

## 5. 핵심 대칭성 결과 (Key Symmetry Result: Ablation Proof)

```text
                            State Integrity          Runtime Confinement
                        (S1 Invalid Mutation)       (S2-S4 Capability Escape)
B0 Access-only                   ✗ (100% 유출)               ✗ (0% 방어)
B1 Transition-only               ✓ (0% 유출)                 ✗ (0% 방어)
B2 Runtime-only                  ✗ (100% 유출)               ✓ (100% 방어)
P  Full-PBEA                     ✓ (0% 유출)                 ✓ (100% 방어)
```

- **B1**: 트랜지션 불변식을 검증하여 S1 상태 오염을 차단하지만, OS 레벨 격리가 없어 S2(파일 탈취), S3(프로세스 실행), S4(네트워크 유출)를 전혀 제어하지 못함.
- **B2**: OpenBSD `pledge`/`unveil` 커널 격리로 S2–S4 런타임 탈출을 100% 차단하지만, 애플리케이션 불변식 검증이 없어 S1 비정상 상태(금액 0)가 그대로 커밋됨.
- **P (Full-PBEA)**: 두 계층을 단일 실행 정책으로 바인딩하여 양쪽 공격을 모두 완벽히 방어함.

---

## 6. Effect-Family 분해 보안 메트릭

| Effect Family | 측정 지표 | B0 Access-only | B1 Transition-only | B2 Runtime-only | P Full-PBEA |
|---|---|:---:|:---:|:---:|:---:|
| **State Integrity** | S1 Invalid State Rate | 100.0% | **0.0%** | 100.0% | **0.0%** |
| **Runtime Confinement** | S2 Filesystem Containment | 0.0% | 0.0% | **100.0%** | **100.0%** |
| **Runtime Confinement** | S3 Process Exec Containment | 0.0% | 0.0% | **100.0%** | **100.0%** |
| **Runtime Confinement** | S4 Egress Network Containment | 0.0% | 0.0% | **100.0%** | **100.0%** |
| **Runtime Confinement** | Aggregate CCR (S2–S4) | 0.0% | 0.0% | **100.0%** | **100.0%** |
| **Policy Binding** | S8 Digest Mismatch Accept Rate | 100.0% | **0.0%** | 100.0% | **0.0%** |
| **Fail-Closed Startup** | S5 Aggregate FCR | 0.0% | 50.0% | **100.0%** | **100.0%** |
| **Outcome Semantics** | S6 Quarantine Rate | 0.0% | **100.0%** | 0.0% | **100.0%** |
| **Benign Preservation** | S0 BRSR | **100.0%** | **100.0%** | **100.0%** | **100.0%** |

---

## 7. S0 Steady-State 및 Startup 벤치마크 실측치 (5,000회 측정)

### 7.1 정상 요청 정상상태 처리 시간 (Steady-State Latency)

| 모드 | 반복 수 ($n$) | Min ($\mu$s) | P50 Median ($\mu$s) | P95 ($\mu$s) | P99 ($\mu$s) | Mean ($\mu$s) | P50 Overhead vs B0 |
|---|---:|---:|---:|---:|---:|---:|:---:|
| **Access-only (B0)** | 5,000 | 0.50 | **0.70** | 0.70 | 1.00 | 0.69 | Baseline |
| **Runtime-only (B2)** | 5,000 | 0.60 | **0.70** | 0.70 | 0.80 | 0.69 | **+0.0%** |
| **Transition-only (B1)** | 5,000 | 178.00 | **208.19** | 262.39 | 378.59 | 200.72 | +29,642.1% |
| **Full-PBEA (P)** | 5,000 | 166.30 | **185.00** | 218.50 | 320.29 | 189.69 | +26,327.9% |

- **주요 발견**: Full-PBEA 정상 상태 트랜잭션 처리 시간은 **185.00 µs (0.185 ms)**로 밀리초 미만의 매우 빠른 속도를 기록함.
- B0 대비 B2의 오버헤드가 0.0%라는 사실은 OpenBSD `pledge`/`unveil` 커널 제약이 프로세스 기동 시 설치된 이후 정상 메모리/허용 작업 경로에 **추가 지연을 전혀 발생시키지 않음**을 실증함.

### 7.2 서비스 1회성 기동 시간 (Daemon Startup)

- **Access-only (B0)**: 46.14 ms
- **Transition-only (B1)**: 45.77 ms
- **Runtime-only (B2)**: 43.18 ms
- **Full-PBEA (P)**: **42.40 ms** (JSON Schema 컴파일 42.25 ms + Sandboxing 설치 0.09 ms)

---

## 8. Claim-Boundary / Adaptive-Adversary 검증 결과

1. **BT1 (Allowed Endpoint Misuse)**:
   - 정책상 명시적으로 허용된 루프백 포트(`127.0.0.1:8990`)로의 데이터 전송이 Full-PBEA(P)를 포함한 모든 모드에서 정상 성공(`permitted`).
   - PBEA는 정책 범위 밖의 탈출을 엄격히 차단하지만, 정책이 명시적으로 허용한 행위에 대해 자의적 의도 추론(Heuristic IDS)을 수행하지 않는다는 **Bounded Claim**을 실증.
2. **BT2 (Symlink Traversal Across Unveil Boundary)**:
   - 허용 디렉터리 내에 외부 기밀 파일을 가리키는 심볼릭 링크를 배치하여 읽기 시도.
   - B0/B1: 호스트 OS 레벨에서 심볼릭 링크를 따라가 외부 파일 읽기 성공(`read-succeeded`).
   - B2/P: OpenBSD 커널 VFS 계층(`unveil`)이 실제 대상 경로를 검사하여 `ENOENT` (errno 2)로 **읽기 완전 차단**(`traversal-denied`).

---

## 9. 생성된 아티팩트 및 논문 수정용 파일

- **논문 수정용 통합 입력서**: [`evaluation/revision_inputs.md`](file:///d:/_Work/goat_bank/pbea/evaluation/revision_inputs.md)
- **실험 보고서 모음**:
  - [`docs/work_reports/202_pbea_rev_round_1/comparative_evaluation_report_v2.md`](file:///d:/_Work/goat_bank/pbea/docs/work_reports/202_pbea_rev_round_1/comparative_evaluation_report_v2.md)
  - [`docs/work_reports/202_pbea_rev_round_1/s0_steady_state_overhead_report.md`](file:///d:/_Work/goat_bank/pbea/docs/work_reports/202_pbea_rev_round_1/s0_steady_state_overhead_report.md)
  - [`docs/work_reports/202_pbea_rev_round_1/claim_boundary_report.md`](file:///d:/_Work/goat_bank/pbea/docs/work_reports/202_pbea_rev_round_1/claim_boundary_report.md)
- **LaTeX & CSV 테이블 (`docs/work_reports/202_pbea_rev_round_1/generated/`)**:
  - `family_metrics.tex` & `family_metrics.csv`
  - `scenario_matrix.tex` & `scenario_matrix.csv`
  - `s0_latency.tex` & `s0_latency.csv`
  - `startup_latency.csv`
  - `boundary_results.tex` & `boundary_results.csv`
  - `comparative_security.tex` & `aggregate_metrics.csv`
  - `security_metrics.tex`
- **SHA-256 Manifest**:
  - [`docs/work_reports/202_pbea_rev_round_1/manifests/manifest.json`](file:///d:/_Work/goat_bank/pbea/docs/work_reports/202_pbea_rev_round_1/manifests/manifest.json)
  - [`docs/work_reports/202_pbea_rev_round_1/manifests/manifest.sha256`](file:///d:/_Work/goat_bank/pbea/docs/work_reports/202_pbea_rev_round_1/manifests/manifest.sha256)
