# Claim-Boundary & Adaptive-Adversary Experiment Report

**Environment**: OpenBSD 7.9 (GENERIC.MP#449 amd64)  
**Source Revision**: `62229cd`  
**Test Harness**: `poa-verifier-example/boundary_probe`

---

## 1. Objective

A common reviewer criticism for policy-enforcement security architectures is that evaluation suites only test attacks that the system is engineered to catch (self-referential benchmarks), or that authors claim universal, intent-aware threat prevention.

To rigorously address this, PBEA defines two empirical **Claim-Boundary Stress Tests (BT1 & BT2)** that demonstrate the precise, bounded nature of PBEA's security claims:
> *PBEA strictly constrains operations to the declared Effective Policy; it does not claim to infer malicious intent when an action falls entirely within an explicitly permitted capability.*

---

## 2. Test BT1: Allowed Endpoint Misuse

### Test Setup
- **Policy Configuration**: An outbound network rule explicitly permitting TCP loopback connection to `127.0.0.1:8990` is included in the verified Effective Policy.
- **Adversarial Action**: The process attempts to connect and exfiltrate a marker payload to `127.0.0.1:8990`.
- **Hypothesis**: Under Full-PBEA (P), because the destination is explicitly declared in the policy allowlist, connection and data delivery **must succeed**.

### Results
| Mode | Allowed in Policy | Connection Attempted | Delivery Succeeded | Observed Outcome | Interpretation |
|---|:---:|:---:|:---:|---|---|
| **Access-only (B0)** | Yes | Yes | Yes | `permitted` | Unconstrained perimeter mode |
| **Transition-only (B1)** | Yes | Yes | Yes | `permitted` | Unconstrained runtime network |
| **Runtime-only (B2)** | Yes | Yes | Yes | `permitted` | Allowed by network allowlist |
| **Full-PBEA (P)** | Yes | Yes | Yes | `permitted` | **Policy-bound delivery succeeds** |

### Academic Claim Grounding:
This confirms that PBEA is a deterministic policy-confinement architecture, not an arbitrary heuristic IDS/IPS. If a policy administrator authorizes an endpoint, PBEA faithfully honors that declaration.

---

## 3. Test BT2: Filesystem Symlink Traversal Across Unveil Boundary

### Test Setup
- **Directory Layout**:
  - `/tmp/pbea-boundary/allowed/` (Unveiled with read permissions `"r"`)
  - `/tmp/pbea-boundary/outside/secret.txt` (Not in unveiled path set)
  - `/tmp/pbea-boundary/allowed/symlink_to_outside.txt` $\rightarrow$ pointing to `/tmp/pbea-boundary/outside/secret.txt`
- **Adversarial Action**: Process attempts to read the target file through the symlink inside the allowed directory.
- **Hypothesis**: Under B0 and B1 (no sandbox), symlink resolution succeeds. Under B2 and P (OpenBSD `unveil` active), the kernel resolves the destination path and rejects access with `ENOENT` (errno 2).

### Results
| Mode | Sandbox Active | Read Attempted | Read Succeeded | OS Errno | Observed Outcome | Kernel Enforcement Interpretation |
|---|:---:|:---:|:---:|:---:|---|---|
| **Access-only (B0)** | No | Yes | Yes | None | `read-succeeded` | Host OS allows symlink without sandbox |
| **Transition-only (B1)** | No | Yes | Yes | None | `read-succeeded` | Transition guards cannot block OS symlink traversal |
| **Runtime-only (B2)** | **Yes** | Yes | **No** | **2 (ENOENT)** | `traversal-denied` | **OpenBSD unveil kernel blocks external target** |
| **Full-PBEA (P)** | **Yes** | Yes | **No** | **2 (ENOENT)** | `traversal-denied` | **OpenBSD unveil kernel blocks external target** |

### Academic Claim Grounding:
OpenBSD `unveil(2)` operates at the VFS namei resolution layer. Even if an adversary crafts a symlink within an authorized directory tree, the kernel prevents access to the unauthorized real path outside the unveil set.
