#!/usr/bin/env python3
"""Fail-closed semantic validator for 4-mode PBEA comparison evidence."""
import argparse, collections, json, pathlib, sys
import jsonschema

MODES = ("access-only", "transition-only", "runtime-only", "full-pbea")
SCENARIOS = tuple(f"S{i}" for i in range(9))
SCHEMA = json.loads((pathlib.Path(__file__).parent / "evidence.schema.json").read_text())
SCHEMA_VALIDATOR = jsonschema.Draft202012Validator(SCHEMA)

def expected(mode, scenario, iteration):
    if scenario == "S0":
        return "commit" if mode in ("transition-only", "full-pbea") else "success"
    if scenario in ("S1", "S8"):
        return "reject" if mode in ("transition-only", "full-pbea") else "success"
    if scenario == "S2":
        return "reject" if mode in ("runtime-only", "full-pbea") else "success"
    if scenario == "S3":
        return "terminated" if mode in ("runtime-only", "full-pbea") else "success"
    if scenario == "S4":
        return "reject" if mode in ("runtime-only", "full-pbea") else "success"
    if scenario == "S5":
        if mode in ("runtime-only", "full-pbea"):
            return "startup-failure"
        if mode == "transition-only" and iteration % 2 == 1:
            return "startup-failure"
        return "success"
    if scenario == "S6":
        return "quarantine" if mode in ("transition-only", "full-pbea") else "success"
    if scenario == "S7":
        return "abort" if mode in ("transition-only", "full-pbea") else "success"
    raise AssertionError(f"unknown scenario: {scenario}")

def load(paths):
    for path in paths:
        for no, line in enumerate(path.read_text().splitlines(), 1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except Exception as e:
                raise ValueError(f"{path}:{no}: {e}") from e

def validate(records, require_complete=True):
    errors = []
    ids = set()
    cells = collections.Counter()
    commits = set()
    platforms = set()
    required = {
        "run_id", "experiment_id", "scenario_id", "mode", "iteration", "seed",
        "timestamp", "source_commit", "platform", "build_profile", "policy_digest",
        "actor_authenticated", "access_authorized", "operation", "expected_outcome",
        "observed_outcome", "malicious_effect_attempted", "malicious_effect_succeeded",
        "state_hash_before", "state_hash_after", "state_changed", "capability_type",
        "target", "os_errno", "exit_code", "signal", "listener_opened",
        "business_loop_entered", "duration_us", "status", "details"
    }
    for i, r in enumerate(records, 1):
        schema_errors = sorted(SCHEMA_VALIDATOR.iter_errors(r), key=lambda e: list(e.absolute_path))
        if schema_errors:
            errors.append(f"record {i}: schema: {schema_errors[0].message}")
        missing = required - r.keys()
        if missing:
            errors.append(f"record {i}: missing {sorted(missing)}")
            continue
        extra = r.keys() - required
        if extra:
            errors.append(f"record {i}: unknown fields {sorted(extra)}")
        if r["run_id"] in ids:
            errors.append(f"record {i}: duplicate run_id")
        ids.add(r["run_id"])
        commits.add(r["source_commit"])
        platforms.add(r["platform"])
        key = (r["mode"], r["scenario_id"], r["iteration"])
        cells[key] += 1
        if r["mode"] not in MODES or r["scenario_id"] not in SCENARIOS:
            errors.append(f"record {i}: invalid mode/scenario")
        if not r["actor_authenticated"] or not r["access_authorized"]:
            errors.append(f"record {i}: precondition false")
        exp = expected(r["mode"], r["scenario_id"], r["iteration"])
        if r["expected_outcome"] != exp or r["observed_outcome"] != exp:
            errors.append(f"record {i}: expected/observed mismatch (expected {exp}, got observed {r['observed_outcome']})")
        if r["state_changed"] != (r["state_hash_before"] != r["state_hash_after"]):
            errors.append(f"record {i}: state hash inconsistency")
        if r["malicious_effect_succeeded"] and not r["malicious_effect_attempted"]:
            errors.append(f"record {i}: succeeded without attempt")
        if (r["mode"] in ("access-only", "runtime-only")) != (r["policy_digest"] is None):
            errors.append(f"record {i}: digest null rule (mode={r['mode']}, digest={r['policy_digest']})")
        if r["exit_code"] is not None and r["signal"] is not None:
            errors.append(f"record {i}: exit_code and signal both set")
        if not isinstance(r["duration_us"], int) or r["duration_us"] < 0:
            errors.append(f"record {i}: bad duration")
        if r["scenario_id"] == "S3" and r["mode"] in ("runtime-only", "full-pbea") and not r["signal"]:
            errors.append(f"record {i}: pledge termination lacks signal")
        if r["scenario_id"] == "S7":
            guarded = r["mode"] in ("transition-only", "full-pbea")
            if r["capability_type"] != "fault-injection" or r["target"] != "after-candidate-before-commit":
                errors.append(f"record {i}: S7 fault location metadata mismatch")
            if guarded:
                if r["observed_outcome"] != "abort":
                    errors.append(f"record {i}: guarded S7 must abort")
                if r["state_hash_before"] != r["state_hash_after"] or r["state_changed"]:
                    errors.append(f"record {i}: S7 abort changed state")
                if r["malicious_effect_succeeded"]:
                    errors.append(f"record {i}: S7 abort cannot report malicious effect success")
            else:
                if r["malicious_effect_attempted"] or r["malicious_effect_succeeded"]:
                    errors.append(f"record {i}: unguarded S7 is not-applicable and must not report a fault effect")
                if r["observed_outcome"] != "success":
                    errors.append(f"record {i}: unguarded S7 direct path must report success")
        if r["observed_outcome"] in ("reject", "quarantine", "abort", "terminated", "startup-failure") and r["state_changed"]:
            errors.append(f"record {i}: non-commit changed state")
    if len(commits) != 1:
        errors.append(f"provenance: source commits={sorted(commits)}")
    if len(platforms) != 1:
        errors.append(f"provenance: platforms={sorted(platforms)}")
    if require_complete:
        expected_keys = {(m, s, i) for m in MODES for s in SCENARIOS for i in range(1, 31)}
        if set(cells) != expected_keys:
            errors.append(f"coverage differs: missing={len(expected_keys - set(cells))} extra={len(set(cells) - expected_keys)}")
        bad = [k for k, v in cells.items() if v != 1]
        if bad:
            errors.append(f"duplicate cells: {bad[:5]}")
        if len(records) != 1080:
            errors.append(f"record count {len(records)} != 1080")
    return errors

def main():
    p = argparse.ArgumentParser()
    p.add_argument("paths", nargs="+", type=pathlib.Path)
    p.add_argument("--allow-partial", action="store_true")
    a = p.parse_args()
    records = list(load(a.paths))
    errors = validate(records, not a.allow_partial)
    if errors:
        print("\n".join(errors), file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps({"status": "valid", "records": len(records), "cells": len(records)}, sort_keys=True))

if __name__ == "__main__":
    main()
